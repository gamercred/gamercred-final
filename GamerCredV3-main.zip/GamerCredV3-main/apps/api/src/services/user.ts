import { db } from '../db/index.js';
import { users } from '../db/schema.js';
import { eq, sql } from 'drizzle-orm';
import {
  getPlayerSummary,
  getOwnedGames,
  getRatings,
  enrichGames,
  calculateCred,
  type EnrichedGame,
} from './steam.js';
import type { User } from '../db/schema.js';
import { logger } from '../lib/logger.js';

const CRED_TTL_MS = 15 * 60 * 1000;

export async function upsertUserFromSteam(steamId: string): Promise<User | null> {
  const player = await getPlayerSummary(steamId);
  if (!player) return null;
  const values = {
    steamId: player.steamid,
    personaName: player.personaname ?? 'Unknown',
    avatar: player.avatarfull ?? '',
    profileUrl: player.profileurl ?? '',
    country: player.loccountrycode ?? null,
  };
  const [row] = await db
    .insert(users)
    .values(values)
    .onConflictDoUpdate({
      target: users.steamId,
      set: {
        personaName: sql`excluded.persona_name`,
        avatar: sql`excluded.avatar`,
        profileUrl: sql`excluded.profile_url`,
        country: sql`excluded.country`,
      },
    })
    .returning();
  return row ?? null;
}

export async function ensureCred(
  steamId: string,
  opts: { force?: boolean } = {}
): Promise<{ user: User; games: EnrichedGame[] }> {
  let user = (await db.select().from(users).where(eq(users.steamId, steamId)))[0];
  if (!user) {
    const created = await upsertUserFromSteam(steamId);
    if (!created) throw new Error('STEAM_USER_NOT_FOUND');
    user = created;
  }
  const stale =
    opts.force ||
    !user.lastCalculatedAt ||
    Date.now() - new Date(user.lastCalculatedAt).getTime() > CRED_TTL_MS;

  if (!stale) {
    // Return user as-is, but still need to load games for display
    const games = await getOwnedGames(steamId);
    const ratings = await getRatings(games);
    const enriched = enrichGames(games, ratings);
    return { user, games: enriched };
  }

  logger.info({ steamId }, 'calculating CRED');
  const games = await getOwnedGames(steamId);
  const ratings = await getRatings(games);
  const enriched = enrichGames(games, ratings);
  const { cred, totalHours, avgRating } = calculateCred(enriched);

  const [updated] = await db
    .update(users)
    .set({
      credScore: cred,
      totalGames: enriched.length,
      totalHours,
      avgRating,
      lastCalculatedAt: new Date(),
    })
    .where(eq(users.steamId, steamId))
    .returning();

  return { user: updated ?? user, games: enriched };
}
